package com.company;

interface IPublishingArtifact
{
    String Publish();
}
