package com.company;

class Country
{
    private int ID;
    private String countryCode;

    int getID() { return this.ID; }
    void setID(int ID) { this.ID = ID; }

    String getCountryCode() { return this.countryCode; }
    void setCountryCode(String countryCode) { this.countryCode = countryCode; }
}
