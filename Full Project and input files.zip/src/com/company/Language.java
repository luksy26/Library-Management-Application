package com.company;

class Language
{
    private int ID;
    private String code, name;

    int getID() { return this.ID; }
    void setID(int ID) { this.ID = ID; }

    String getCode() { return this.code; }
    void setCode(String code) { this.code = code; }

    String getName() { return this.name; }
    void setName(String name) { this.name = name;}
}